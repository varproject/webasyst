<?php

return shopLkPluginRoutingProvider::getRouting();
