<?php

shopLkPluginSchema::ensure();
