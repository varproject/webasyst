<?php

class shopLkPluginFrontendAuthLayout extends waLayout
{
    protected $params = [];

    // Подготовить общие параметры standalone-страниц авторизации
    public function execute()
    {
        $settings = shopLkPluginNavigation::getSettings();
        $auth     = !empty($settings['auth']) && is_array($settings['auth']) ? $settings['auth'] : $settings;

        $this->params = array_merge($this->params, [
            'plugin_static_url'  => shopLkPluginNavigation::getStaticUrl(),
            'return_url'         => shopLkPluginNavigation::getFirstMenuUrl(),

            'auth_url'           => shopLkPluginNavigation::getAuthUrl(),
            'signup_url'         => shopLkPluginNavigation::getSignupUrl(),
            'forgotpassword_url' => shopLkPluginNavigation::getForgotpasswordUrl(),

            'auth_bg_url'        => $auth['auth_bg_url'] ?? '',
            'auth_logo_img_url'  => $auth['auth_logo_img_url'] ?? '',
            'auth_logo_text'     => $auth['auth_logo_text'] ?? '',
            'auth_logo_slogan'   => $auth['auth_logo_slogan'] ?? '',
            'auth_hero_title'    => $auth['auth_hero_title'] ?? '',
            'auth_hero_text'     => $auth['auth_hero_text'] ?? '',
            'auth_shop_url'      => $auth['auth_shop_url'] ?? '',
        ]);

        $this->view->assign($this->params);
    }
}
