<?php

class shopLkPlugin extends shopPlugin
{
    // Подключить пользовательские функции и модификаторы
    public function __construct($info)
    {
        parent::__construct($info);

        foreach (['functions.php', 'modifiers.php'] as $file) {
            $path = $this->path . '/lib/config/' . $file;

            if (file_exists($path)) {
                require_once $path;
            }
        }
    }

    // Получить ссылку на кабинет
    public static function getFrontUrl($absolute = false)
    {
        $settings = shopLkPluginNavigation::getSettings();

        if (empty($settings['main']['enabled'])) {
            return shopLkPluginNavigation::getDefaultCabinetFrontUrl($absolute);
        }

        return shopLkPluginNavigation::getRootFrontUrl($absolute);
    }

    // Нормализовать и сохранить настройки плагина
    public function saveSettings($settings = [])
    {
        $old_settings = $this->getSettings() ?: [];

        if (empty($settings['main']) || !is_array($settings['main'])) {
            $settings['main'] = [];
        }

        $old_route = $this->prepareRoute(
            $old_settings['main']['route'] ?? shopLkPluginNavigation::DEFAULT_ROOT_URL,
            !empty($old_settings['main']['b2b_mode'])
        );

        $is_b2b = !empty($settings['main']['b2b_mode']);
        $route  = $this->prepareRoute($settings['main']['route'] ?? '', $is_b2b);

        $settings['main']['route']           = $route;
        $settings['main']['redirect_routes'] = $this->prepareRedirectRoutes($old_settings, $old_route, $route);

        $settings['sections'] = $this->prepareSections($settings['sections'] ?? []);
        $settings             = $this->prepareDomains($settings);

        parent::saveSettings($settings);

        // Снимок нужен для редиректа со старых URL, если плагин выключили в Installer
        $model = new waAppSettingsModel();
        $model->set('shop', 'lk_runtime_settings', json_encode($settings));

        shopLkPluginNavigation::reset($settings);

        return [
            'main_cabinet_url' => self::getFrontUrl(true),
            'main_input_url'   => $settings['main']['route'],
        ];
    }

    // Подготовить route кабинета
    protected function prepareRoute($route, $is_b2b)
    {
        $route = shopLkPluginSlugify::generate($route, false, 64, '-');

        if ($route === '' && !$is_b2b) {
            return shopLkPluginNavigation::DEFAULT_ROOT_URL;
        }

        return $route;
    }

    // Подготовить старые root-адреса для редиректа
    protected function prepareRedirectRoutes($old_settings, $old_route, $route)
    {
        $routes = $old_settings['main']['redirect_routes'] ?? [];
        $routes = is_array($routes) ? $routes : [];

        if ($old_route !== '' && $old_route !== $route) {
            $routes[] = $old_route;
        }

        $result = [];

        foreach ($routes as $item) {
            $item = shopLkPluginSlugify::generate($item, false, 64, '-');

            if ($item !== '' && $item !== $route) {
                $result[] = $item;
            }
        }

        return array_slice(array_values(array_unique($result)), -5);
    }

    // Подготовить настройки разделов
    protected function prepareSections($sections)
    {
        $sections = is_array($sections) ? $sections : [];

        foreach ($sections as $id => $section) {
            if (!is_array($section)) {
                continue;
            }

            // Название раздела
            if (isset($section['name'])) {
                $sections[$id]['name'] = trim((string) $section['name']);
            }

            // Иконка раздела
            if (isset($section['icon'])) {
                $sections[$id]['icon'] = shopLkPluginGetIcon::font($section['icon']);
            }

            // URL-путь раздела
            if (isset($section['path'])) {
                $sections[$id]['path'] = shopLkPluginSlugify::generate($section['path'], false, 64, '-');
            }
        }

        if (empty($sections['profile']) || !is_array($sections['profile'])) {
            $sections['profile'] = [];
        }

        // Профиль системный и всегда должен быть доступен по прямой ссылке
        $sections['profile']['enabled'] = 1;

        return $sections;
    }

    // Подготовить настройки доменов
    protected function prepareDomains($settings)
    {
        $mode = $settings['main']['domain_mode'] ?? 'all';

        if ($mode !== 'selected') {
            return $settings;
        }

        $domains = [];

        foreach ((array) ($settings['main']['domains'] ?? []) as $domain) {
            $domain = shopLkPluginNavigation::normalizeDomain($domain);

            if ($domain !== '') {
                $domains[] = $domain;
            }
        }

        $domains = array_values(array_unique($domains));

        if (empty($domains)) {
            throw new waException('Выберите хотя бы один домен');
        }

        $settings['main']['domains'] = $domains;

        return $settings;
    }
}