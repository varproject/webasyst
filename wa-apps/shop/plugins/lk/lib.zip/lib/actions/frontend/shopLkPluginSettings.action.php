<?php

class shopLkPluginSettingsAction extends waViewAction
{
    public function execute()
    {
        $this->view->assign([
            'is_htmx'              => (bool) waRequest::server('HTTP_HX_REQUEST'),
            'cabinet_url'          => shopLkPluginNavigation::getRootFrontUrl(true),
            'settings'             => shopLkPluginNavigation::getSettings(),
            'settings_tabs'        => shopLkPluginNavigation::getSettingsTabs(),
            'domains'              => wa()->getRouting()->getDomains(),
            'settings_path'        => wa()->getAppPath('plugins/lk/templates/actions/settings/', 'shop'),
            'settings_legacy_path' => wa()->getAppPath('plugins/lk/templates/actions-legacy/settings/', 'shop'),
        ]);

        $main_settings = wa('shop')->getPlugin('lk')->getSettings('sections');
        // dd($main_settings);

        // $domain = wa()->getRouting()->getDomain(null, false, true);
        // $url = wa()->getRouteUrl('shop/frontend', array(), true, $domain);

        // dd(wa('shop')->getPlugin('lk'));

        // dd(wa()->getRouting()->getRoutes('webasyst2.loc'));


    }
}
