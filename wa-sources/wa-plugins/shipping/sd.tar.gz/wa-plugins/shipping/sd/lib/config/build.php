<?php
return 48;
