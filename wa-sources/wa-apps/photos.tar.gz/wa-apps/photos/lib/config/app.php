<?php

return array(
    'name' => 'Photos',
    'icon' => 'img/photos.svg',
    'rights' => true,
    'frontend' => true,
    'themes' => true,
    'auth' => true,
    'plugins' => true,
    'pages' => true,
    'mobile' => true,
    'version' => '2.2.4',
    'vendor' => 'webasyst',
    'my_account' => true,
    'sash_color' => '#af71b3',
    'ui' => '2.0'
);
